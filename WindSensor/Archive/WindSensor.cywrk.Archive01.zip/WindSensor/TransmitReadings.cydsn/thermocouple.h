#ifndef thermocouple_h
#define thermocouple_h

#include <project.h>
#include <math.h>

int16 gettemperature();

#endif
	